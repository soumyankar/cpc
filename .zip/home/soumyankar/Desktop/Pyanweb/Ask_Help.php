<?php
  session_start();
  include ("connect.php");
  include "HashGenerator.php";

  if(isset($_POST['next']))
  {
      $name=$_POST['name'];
      $address=$_POST['address'];
      $pin=$_POST['pin'];
      $state=$_POST['state'];
      $country=$_POST['country'];
      $details=$_POST['details'];
      $sql="INSERT INTO `help_protection` (`complaint_id`, `name`, `address`, `pin`, `state`, `country`, `complaint`) VALUES (NULL, '$name', '$address', '$pin' , '$state', '$country', '$details')";
      $sql2="Select LAST_INSERT_ID() as c_id";
      $query=mysqli_query($conn,$sql);
      if(!$query)
      {
        echo "Not Inserted". "<br>" . mysqli_error($conn);
      } 
        $query2=mysqli_query($conn,$sql2);
        $result2=mysqli_fetch_assoc($query2);
        $c_id=($result2['c_id']);
        // var_dump($c_id);
        
        $obj = new HashGenerator;
        $hash_id = $obj->encode($c_id);

        $sql3="UPDATE help_protection SET hash_id='$hash_id' WHERE complaint_id='$c_id'";
        $query=mysqli_query($conn,$sql3);
        if(!$query)
        {
          echo "Not Updated". "<br>" . mysqli_error($conn);
        }
        header("location:Confirmation_Page.php?c_id=$hash_id");
       }
  
?>
<html>
<head>
  <title>Ask Help/Protection</title>

  <!-- Bootstrap Core CSS --><link href="css/bootstrap.min.css" rel="stylesheet">
  <script type="text/javascript"  src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.1/jquery.min.js"></script>

    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>

    <script>

    (function($,W,D)
    {
      var JQUERY4U = {};

      JQUERY4U.UTIL =
      {
        setupFormValidation: function()
        {
          //form validation rules
          $("#quick_complaint").validate({
            rules: {
              name: {
                required: true,
                minlength:5,
              }
              address: {
                required: true,
                minlength:5,
              }
              state: {
                required: true,
                minlength:1,
              }
              country: {
                required: true,
                minlength:1,
              }
            },
          });
        }
      }

      //when the dom has loaded setup form validation rules
      $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
      });

    })(jQuery, window, document);


  </script>
</head>
<body>
  <h1 align="center">Ask Help/Protection</h1>
  <div class="container">
    <div class="jumbotron">
      <form class="form-horizontal col-md-offset-3" id="quick_complaint" role="form" method="post" action="">
        <div class="form-group">
                    <label class="col-lg-3 control-label">Name*</label>
                    <div class="col-lg-4">
                      <input class="form-control" name="name" type="text" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-lg-3 control-label">Address*</label>
                    <div class="col-lg-4">
                      <input class="form-control" name="address" type="text" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-lg-3 control-label">Pin*</label>
                    <div class="col-lg-4">
                      <input class="form-control" name="pin" type="text" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-lg-3 control-label">State*</label>
                    <div class="col-lg-4">
                      <input class="form-control" name="state" type="text" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-lg-3 control-label">Country*</label>
                    <div class="col-lg-4">
                      <input class="form-control" name="country" type="text" required>
                    </div>
                </div>
        <div class="form-group">
                    <label class="col-md-3 control-label">Additional Details*</label>
                    <div class="col-md-8">
                      <textarea id="complaint" class="form-control" name="details" rows="7" ></textarea>
                    </div>
                    <img src="img/mic.png" style="height:30px;width:30px" id="start-button" onclick="toggle()">
                  </div>
                <div class="form-group">
                    <label class="col-md-3 control-label"></label>
                    <div class="col-md-8">
                      <input class="btn btn-primary" value="Submit" name="next" type="submit">
                      <input class="btn btn-default" value="Cancel" type="reset" id="cancel">
                    </div>
                  </div>
      </form>
    </div>
  </div>

  <script type="text/javascript">
      $("#cancel").click(function(){
          
        window.location.href = 'index.php';
      });
    </script>
  <script type="text/javascript">
      var p=0;
      var k;
      function toggle()
      {
        
        if(p==0)
          {
            document.getElementById('start-button').src='img/red-mic.png';
            startDictation(event);
            p=1;
          }
        else
          {
            stop(event);
            p=0;
          }

      }
      var final_transcript = '';
      var recognizing = false;

      if ('webkitSpeechRecognition' in window) {

        var recognition = new webkitSpeechRecognition();

        recognition.continuous = true;
        recognition.interimResults = true;

        recognition.onstart = function() {
          recognizing = true;
        };

        recognition.onerror = function(event) {
          console.log(event.error);
        };

        recognition.onend = function() {
          recognizing = false;
        };

        recognition.onresult = function(event) {
          var interim_transcript = '';
          for (var i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
              final_transcript += event.results[i][0].transcript;
              stop(event);
            } else {
              interim_transcript += event.results[i][0].transcript;
            }
          }
          final_transcript = capitalize(final_transcript);
          complaint.innerHTML=linebreak(final_transcript);
          if(k==0)
          complaint.innerHTML=linebreak(interim_transcript);
        };
      }

      var two_line = /\n\n/g;
      var one_line = /\n/g;
      function linebreak(s) {
        return s.replace(two_line, '<p></p>').replace(one_line, '<br>');
      }

      function capitalize(s) {
        return s.replace(s.substr(0,1), function(m) { return m.toUpperCase(); });
      }
      function stop(event)
      {
        k=1;
        recognition.stop();
        document.getElementById('start-button').src='img/mic.png';
      }

      function startDictation(event) {
        k=0;
        if (recognizing) {
          k=1;
          recognition.stop();
          return;
        }
        final_transcript = '';
        recognition.lang = 'en-US';
        recognition.start();
        complaint.innerHTML = '';
        
      }
    </script>

    <!-- jQuery --->
  <script src="js/jquery.js"></script>

  <!-- Bootstrap Core JavaScript -->
  <script src="js/bootstrap.min.js"></script>

  <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
</body>
</html>