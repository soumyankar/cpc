<?php
  session_start();
  include "connect.php";
  $_SESSION["id"]=$_GET['c_id'];
?>

<!DOCTYPE HTML>
<head>
	<title>Complaint Box</title>
</head>
<body>
    <h2><p align="center">CONFIRMATION PAGE</p></h2> 
     <h3><p align="center">Your complaint has been registered</p></h3>  
   <form>  	       	
    <div>
        <label for="name">Your Complaint ID: </label>
        <input id="name" name="Complaint ID" value="<?php echo $_SESSION["id"]; ?>"disabled>
    </div>
    <div>
</form>
</body>
<style>
	form {
  margin: 0 auto;
  width: 400px;
  padding: 1em;
  border: 1px solid #CCC;
  border-radius: 1em;
}

form div + div {
  margin-top: 1em;
}

label {
  display: inline-block;
  width: 90px;
  text-align: right;
}

input, textarea {
    font: 1em sans-serif;
    height: 50px;
  width: 300px;
  box-sizing: border-box;
  border: 1px solid #999;
}

input:focus, textarea:focus {
  border-color: #000;
}
</style>
</html>                                            