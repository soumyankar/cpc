
<html>
<head>
  <title>Formal Complaint</title>

  <!-- Bootstrap Core CSS --><link href="css/bootstrap.min.css" rel="stylesheet">
  <script type="text/javascript"  src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.1/jquery.min.js"></script>

    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>

    <script>

    (function($,W,D)
    {
      var JQUERY4U = {};

      JQUERY4U.UTIL =
      {
        setupFormValidation: function()
        {
          //form validation rules
          $("#quick_complaint").validate({
            rules: {
              name: {
                required: true,
                minlength:5,
              }
              city: {
                required: true,
                minlength:5,
              }
              country: {
                required: true,
                minlength:5,
              }
              state: {
                required: true,
                minlength:1,
              }
              complaint: {
                required: true,
                minlength:5,
              }
            },
            submitHandler: function(form) {
              form.submit();
            }
          });
        }
      }

      //when the dom has loaded setup form validation rules
      $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
      });

    })(jQuery, window, document);


  </script>
</head>
<body>
  <h1 align="center">Formal Complaint</h1>
  <div class="container">
    <div class="jumbotron">
      <form class="form-horizontal col-md-offset-3" id="quick_complaint" role="form" method="POST" enctype="multipart/form-data" action="upload.php">
            
        <div class="form-group">
              <label class="col-lg-3 control-label">Name*</label>
              <div  class="col-md-offset-3" align="center" >
              <input type="file" name="image"  onchange="readURL(this);" />
              <img id="blah" src="#" align="right" />
             </div>
                    <div class="col-lg-4"> 
             <!-- class="col-sm-8" -->
                      <input class="form-control" name="name" type="text" placeholder="If unknown then your details" required>
                    </div>
                </div>

        <div class="form-group">
                    <label class="col-lg-3 control-label">Pin*</label>
                    <div class="col-lg-4">
                      <input class="form-control" name="pin" type="text" required>
                    </div>
                </div>
        <div class="form-group">
                    <label class="col-lg-3 control-label">City*</label>
                    <div class="col-lg-4">
                      <input class="form-control" name="city" type="text" required>
                    </div>
                </div>

        <div class="form-group">
                    <label class="col-lg-3 control-label">State*</label>
                    <div class="col-lg-4">
                      <input class="form-control" name="state" type="text" required>
                    </div>
                </div>
        <div class="form-group">
                    <label class="col-lg-3 control-label">Country*</label>
                    <div class="col-lg-4">
                      <input class="form-control" name="country" type="text" required>
                    </div>
                </div>
            
        <div class="form-group">
                    <label class="col-md-3 control-label">Complaint Details*</label>
                    <div class="col-md-8">
                      <textarea id="complaint" class="form-control" name="complaint" rows="7" ></textarea>
                    </div>
                    <img src="img/mic.png" style="height:30px;width:30px" id="start-button" onclick="toggle()">
                  </div>
          <h4 align="left">Relevant Images: </h4>
          
<input type="file" id="fileInput" name="fileInput1"/>

<input type="file" id="fileInput" name="fileInput2" style="margin-top:10px"/>

<input type="file" id="fileInput" name="fileInput3" style="margin-top:10px"/>


                <div class="form-group">
                    <label class="col-md-3 control-label"></label>
                    <div class="col-md-8">
                      <input class="btn btn-primary" value="Submit" name="next" type="submit" style="margin-top:20px">
                      <input class="btn btn-default" value="Cancel" type="reset" id="cancel"  style="margin-top:20px">
                    </div>
                  </div>
      </form>
    </div>
  </div>
  <p>Your Location: <span id="location"></span></p>

<script>
$(document).ready(function(){
    if(navigator.geolocation){
        navigator.geolocation.getCurrentPosition(showLocation);
    }else{ 
        $('#location').html('Geolocation is not supported by this browser.');
    }
});

function showLocation(position){
    var latitude = position.coords.latitude;
    var longitude = position.coords.longitude;
    $.ajax({
        type:'POST',
        url:'getLocation.php',
        data:'latitude='+latitude+'&longitude='+longitude,
        success:function(msg){
            if(msg){
               $("#location").html(msg);
            }else{
                $("#location").html('Not Available');
            }
        }
    });
}
</script>



<script>
   function chooseFile() {
      $("#fileInput").click();
   }
</script>
  <script type="text/javascript">
      $("#cancel").click(function(){
          
        window.location.href = 'index.php';
      });
    </script>
  <script type="text/javascript">
      var p=0;
      var k;
      function toggle()
      {
        
        if(p==0)
          {
            document.getElementById('start-button').src='img/red-mic.png';
            startDictation(event);
            p=1;
          }
        else
          {
            stop(event);
            p=0;
          }

      }
      var final_transcript = '';
      var recognizing = false;

      if ('webkitSpeechRecognition' in window) {

        var recognition = new webkitSpeechRecognition();

        recognition.continuous = true;
        recognition.interimResults = true;

        recognition.onstart = function() {
          recognizing = true;
        };

        recognition.onerror = function(event) {
          console.log(event.error);
        };

        recognition.onend = function() {
          recognizing = false;
        };

        recognition.onresult = function(event) {
          var interim_transcript = '';
          for (var i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
              final_transcript += event.results[i][0].transcript;
              stop(event);
            } else {
              interim_transcript += event.results[i][0].transcript;
            }
          }
          final_transcript = capitalize(final_transcript);
          complaint.innerHTML=linebreak(final_transcript);
          if(k==0)
          complaint.innerHTML=linebreak(interim_transcript);
        };
      }

      var two_line = /\n\n/g;
      var one_line = /\n/g;
      function linebreak(s) {
        return s.replace(two_line, '<p></p>').replace(one_line, '<br>');
      }

      function capitalize(s) {
        return s.replace(s.substr(0,1), function(m) { return m.toUpperCase(); });
      }
      function stop(event)
      {
        k=1;
        recognition.stop();
        document.getElementById('start-button').src='img/mic.png';
      }

      function startDictation(event) {
        k=0;
        if (recognizing) {
          k=1;
          recognition.stop();
          return;
        }
        final_transcript = '';
        recognition.lang = 'en-US';
        recognition.start();
        complaint.innerHTML = '';
        
      }
    </script>

    <!-- jQuery --->
  <script src="js/jquery.js"></script>

  <!-- Bootstrap Core JavaScript -->
  <script src="js/bootstrap.min.js"></script>

  <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
</body>
<style>
  article, aside, figure, footer, header, hgroup, 
  menu, nav, section { display: inline-table; }
</style>
<style>
     .col-sm-8{
           alignment-adjust:before-edge;
      }
</style>
<script>
function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result)
                    .width(80)
                    .height(100);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
  </script>
</html>