<?php
  session_start();
  include ("../connect.php");
  $c_id=$_GET['c_id'];
  $sql="SELECT * FROM `quick_report` WHERE `hash_id` = '$c_id' ";
  $result=mysqli_query($conn,$sql);
  $found=mysqli_num_rows($result);  
?>


<!DOCTYPE HTML>
<head>
	<title>Formal Report Complaint Box</title>
</head>
<body>
     <h2><p align="center">Formal Report Details: </p></h4><br>  
      <ul class="container">
          <li><img src="https://jamesgilberdphotography.weebly.com/uploads/1/3/6/5/13650410/editor/emma-not-smiling-35x45_1.jpg?1502668408" width="100" height="120" border="5" /></li>
      </ul>
   <form>  	       	
    <div>
        <label for="name">Name: </label>
        <input id="name" name="Name" <?php echo $found['name']?> disabled>
    </div>
    <div>
        <label for="name">Pin: </label>
        <input id="number" name="Pin" <?php echo $found['pin'] ?> disabled>
    </div>
    <div>
        <label for="city">City: </label>
        <input id="name" name="City" <?php echo $found['city'] ?>disabled>
    </div>
    <div>
        <label for="city">Country: </label>
        <input id="name" name="Country" <?php echo $found['country'] ?> disabled>
    </div>
    <div>
        <label for="msg">Complaint: </label>
        <textarea id="msg" name="Complaint" <?php echo $found['complaint'] ?> disabled></textarea>
    </div>
</form>
      <div class="Format"><h3 align="center">Other Evidences : </h3></div>
      <ul class="NewContainer">
          <li><img src="https://jamesgilberdphotography.weebly.com/uploads/1/3/6/5/13650410/editor/emma-not-smiling-35x45_1.jpg?1502668408" width="100" height="120" border="5" /></li>
          <li><video width="320" height="240" controls><source src="https://s3.amazonaws.com/codecademy-content/projects/make-a-website/lesson-1/ollie.mp4" type="video/mp4"></video></li>
          <li><img src="https://jamesgilberdphotography.weebly.com/uploads/1/3/6/5/13650410/editor/emma-not-smiling-35x45_1.jpg?1502668408" width="100" height="120" border="5" /></li>
      </ul>
</body>
<style>
form {
  margin: -200px auto;
  width: 400px;
  padding: 1em;
  border: 1px solid #CCC;
  border-radius: 1em;
}
form div + div {
  margin-top: 1em;
}

label {
  display: inline-block;
  width: 90px;
  text-align: right;
}

input, textarea {
    font: 1em sans-serif;

    width: 300px;
    box-sizing: border-box;
    border: 1px solid #999;
}

input:focus, textarea:focus {
  border-color: #000;
}

textarea {
  vertical-align: top;
  height: 5em;
}
.Format{
  margin: 220px auto;
}
.container {
    margin: -100px 200px;
    overflow:hidden;
    list-style:none;
}

.container li {
    float:right;
    text-align:center;
    margin-top: 10em;
}

.container img {
    display:block;
}



.NewContainer {
    margin: -300px 300px;
    overflow:hidden;
    list-style:none;
}

.NewContainer li {
    float:right;
    text-align:center;
    margin-top: 10em;
    margin-right: 1em; 
}

.NewContainer img {
    display:block;
}
</style>
</html>                                            