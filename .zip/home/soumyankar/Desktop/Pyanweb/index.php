<?php 
session_start(); 
include ("connect.php");
include "creds.php";
include "swiftmailer/lib/swift_required.php";
include "HashGenerator.php";

if(isset($_SESSION['user_id']))
	header("location:home.php");

if(isset($_POST['Register'])){

	    $fname=$_POST["fname"];
	    $lname=$_POST["lname"];
	    $email=$_POST["email"];
	    $mob=$_POST["mobile"];
	    $pass=$_POST['password'];

    	$sql="INSERT INTO users (First_Name,Last_Name,Email,Mobile,Password) VALUES ('$fname','$lname','$email','$mob','$pass')";
    	$query=mysqli_query($conn,$sql);
    	if(!$query)
    		echo "Not Inserted" . mysql_error($conn);	  	
	    

		// Create the email and send the message
		$to = '$email'; 
		$email_subject = "Email Confirmation";
		$msg = "This is Confirmation Mail! You have succesfully registered to our website. <br>Your Email ID: ". $email . "<br>Your Password : " . $pass;
		$headers = "From: rohan.panda1@gmail.com"; // This is the email address the generated message will be from. We recommend using something like noreply@yourdomain.com.

		$transport = Swift_SmtpTransport::newInstance('smtp.gmail.com', 465, "ssl");
		  $transport->setUsername($sender_email);
		  $transport->setPassword($sender_pass);

		// mail($to,$email_subject,$email_body,$headers);

		$message=Swift_Message::newinstance();
	  	$message->setFrom(array("websamaritans@gmail.com" =>"NCPCR Minsitry"));
	  	$message->setTo("$email");
	  	$message->setSubject($email_subject);
	  	$message->setBody($msg,'text/html'); 
	  	// $swift->send($message, $failures);
	  	$swift=Swift_Mailer::newinstance($transport);
	  	$swift->send($message);
	  	// echo "<script type='text/javascript'>alert('Mail Sent!');</script>";

	  	header("location: index.php?registered=true");
		}	

		//send message to mobile
	    // $x = SendSMS("127.0.0.1", 8800, "username", "password", $mob, $msg);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="author" content="rohan_panda">
    <meta name="viewport" class="container-fluid" content="width=device-width, initial-scale=1">


	<title>PYANWEB</title>

	<!-- Bootstrap Core CSS --><link href="css/bootstrap.min.css" rel="stylesheet">
	<!-- Custom CSS --><link href="css/agency.css" rel="stylesheet">
	<!-- <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
	<link rel="stylesheet" href="css/login.css" type="text/css">
	<script type="text/javascript"	src="http://ajax.googleapis.com/ajax/libs/jquery/2.2.1/jquery.min.js"></script>
	<script src="js/jquery.md5.js"></script>
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	<!-- Validation  --><script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>

</head>

<body id="page-top" class="index">

	<!-- Navigation -->
	<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header page-scroll">
				<button type="button" class="navbar-toggle" data-toggle="collapse"
					data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span> <span
						class="icon-bar"></span> <span class="icon-bar"></span> <span
						class="icon-bar"></span>
				</button>
				<!-- <a class="navbar-brand page-scroll" href="index.html">NCPCR </a> -->
				<!-- <a href="index.php"><img src="img/logo.jpeg" class="avatar img-circle" height="100" width="100"></a> -->
			</div>

			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse"
				id="bs-example-navbar-collapse-1">

				<ul class="nav navbar-nav navbar-right">
					<li class="hidden"><a href="#page-top"></a></li>
					<li><a class="page-scroll" href="index.php"><b>Home</b></a></li>
					<li><a class="page-scroll" href="local_admin/local_login.php"><b>Local Authority Login</b></a></li>		
					<li><a class="page-scroll" href="#"><b>News</b></a></li>	
					<li><a class="page-scroll" href="help.php"><b>Community</b></a></li>					
				</ul>
			</div>
			<!-- /.navbar-collapse -->
		</div>
		<!-- /.container-fluid -->
	</nav>

	<!-- Header -->




<section class="mySection" style="background-image: url('https://assets.weforum.org/article/image/large_mjpA0klLzLj5YF8dAsY0wBO6rInBF4gIOf5LXL56n9I.jpg')">
		<div class="container-fluid col-md-offset-7 login_section" >
		    <form class="form-signin" id="login_form" action="" method="post">       
				<h3 class="form-signin-heading" style="margin-bottom:20px" align="Center">Our Services</h3>

				<a href="Ask_Help.php" button class="btn btn-lg btn-primary btn-block" type="submit" style="margin-bottom:20px" >Ask Help/Protection</button></a> 
				<a href="Formal_Complaint.php" button class="btn btn-lg btn-danger btn-block register_modal" style="margin-bottom:20px" type="button">Formal Report</button></a>
				<!-- <h3 class="form-signin-heading" align="Center">----</h3>   -->
				<!--<hr size="20">-->
				<a href="quick_complaint.php" class="btn btn-lg btn-success btn-block" type="button">Quick Report</a> 
		    </form>

		</div>

		<!-- <div id="body">
			<div id="featured">
				<div>
					<h2>National Commission for Protection of Child Rights</h2>
					<span>Our website is created with</span>
					<span>inspiration, checked for quality and originality</span>
					<span>and meticulously sliced and coded.</span>
				</div>
			</div>
		</div> -->

		<!-- <div class= 'col-xs-4' style="position:absolute;top:25%;height: 55%;width: 400px; overflow: scroll;">
		<a class="twitter-timeline" href="https://twitter.com/NCPCR_">Tweets by NCPCR_</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
		</div> -->

		<!-- <div  class='col-md-4'><a href="https://twitter.com/NCPCR_" class="twitter-follow-button" data-show-count="false">Follow @NCPCR_</a><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
		</div> -->
		

</section>


	<footer>
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-4">
					<span class="copyright">Copyright &copy; Pyanweb</span><br>
					Contact us: <span class="glyphicon glyphicon-envelope">soumyankarm@gmail.com</span>
				</div>
				<div class="col-md-4">
					<ul class="list-inline social-buttons">
						<li><a href="https://twitter.com/ncpcr_?lang=en"><i class="fa fa-twitter"></i></a></li>
						<li><a href="https://www.facebook.com/NCPCR.Official/"><i class="fa fa-facebook"></i></a></li>
						<li><a href="https://www.linkedin.com/in/ncpcr-child-rights-4a052a12a"><i class="fa fa-linkedin"></i></a></li>
					</ul>
				</div>
				<div class="col-md-4">
					<ul class="list-inline quicklinks">
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="#">Terms of Use</a></li>
					</ul>
				</div>
			</div>
		</div>
	</footer>


<!-- <p>DISCLAIMER : Neither National Informatics Centre or The Office of National Commission for Protection of Child Rights (NCPCR) is responsible for any inadvertent error that may have crept in the information being published on internet.<br>
NOTE : For further details kindly contact National Commission for Protection of Child Rights, 5th Floor,Chanderlok Building ,36 Janpath, New Delhi, PIN 110001
it[dot]ncpcr[at]nic[dot]in Tel.No. 23478200 Fax No. 23724026</p> 


	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal"
						aria-hidden="true">×</button>
					<h4 class="modal-title" id="myModalLabel">
						Registration Form 
					</h4>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-md-8">
							<br>								
							<div class="tab-pane" id="Registration">
								<form role="form" action="" method="post" id="register-form">
					       			<div id="form-content" class="form-group">
					        			<fieldset>
					        				<div class="row">
						            			<div class="form-group col-sm-4">
						                			<label for="name">First Name</label>
						                		</div>
						                		<div class="form-group col-sm-8">
						               			    <input type="text" name="fname" class="form-control" placeholder="Enter your First Name" required/>
						            			</div>
						            		</div>

						            		<div class="row">
						            			<div class="form-group col-sm-4">
						                			<label for="name">Last Name</label>
						                		</div>
						                		<div class="form-group col-sm-8">
						               			    <input type="text" name="lname" class="form-control" placeholder="Enter your Last Name" required/>
						            			</div>
						            		</div>
					
					            			<div class="row">
						            			<div class="form-group col-sm-4">
					                				<label for="mobile">Mobile(+91)</label>
					                			</div>
					                			<div class="form-group col-sm-8">
					                				<input type="number" name="mobile" class="form-control" placeholder="Enter your Mobile Number" required />
					            				</div>
											</div>
											
											<div class="row">
									            <div class="form-group col-sm-4">
									                <label for="email">Email</label>
									             </div>
									             <div class="form-group col-sm-8">
									                <input type="email" name="email" class="form-control" placeholder="Enter your Email Address" required/>
									            </div>
									        </div>

									        <div class="row">
									            <div class="form-group col-sm-4">
									                <label for="email">Password</label>
									             </div>
									             <div class="form-group col-sm-8">
									                <input type="password" name="password" class="form-control" placeholder="Enter your Password" required/>
									            </div>
									        </div>
									        
									        <br>
									        <div class="row">
									            <div class="form-group col-sm-4">
									                <label for='captcha'>Captcha</label>
									            </div>
									            <div class="form-group col-sm-8">
									            <img src="captcha.php?rand=<?php echo rand();?>" id='captchaimg'>
									                <br><br>
											        <input id="captcha_code" name="captcha_code"  class="form-control" type="text" placeholder="Enter the code above" required>
											        <br>
											        Can't read the image? click <a href='javascript: refreshCaptcha();'>here</a> to refresh.
									            </div>
									        </div>									        
											<div class="row">
									            <div class="form-group col-sm-4">
									                <button type="submit" name="Register" class="submit btn btn-md btn-success">Register</button>
										            </div>
										        </div>
										    </div>   
									    </fieldset>
						    		</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>-->
	<!-- jQuery -->
	<!-- <script src="js/jquery.js"></script> -->

	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.min.js"></script>

	<!-- Plugin JavaScript -->
	<!-- <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
	<script src="js/classie.js"></script>
	<script src="js/cbpAnimatedHeader.js"></script> -->

	<!-- Contact Form JavaScript -->
	<script src="js/jqBootstrapValidation.js"></script>
	<script src="js/contact_me.js"></script>

	<!-- Custom Theme JavaScript -->
	<script src="js/agency.js"></script>

	<script type="text/javascript">

		$('.register_modal').click(function(){
			$('#myModal').modal('show');
		});

	</script>

	<script>
        var x=window.location.search.substring(1),y;
        if(x)
        {
            y=x.split('=');
//                console.log(y[0]);
			if(y[0]=='registered')
            	alert("Registration Successful! \nPlease Login to Continue.");
        }
    </script>

    <script type="text/javascript">

    	$('#login').click(function() {
    		
	    	var pass = $('#password').val();
	    	var email = $('#email').val();

	  //   	var salt = "HighSecurity";
	  //       var strMD5 = $.md5(pass);
			// var strMD52 = $.md5(salt);
			// var saltEnc = strMD52+strMD5;
			// console.log('saltEnc');
			// $('#password').val(saltEnc);

			$("#msgbox").addClass('error-warning').html('Validating....').fadeIn(1000);

			$.post("ajax_login.php",{ login_email:email,login_pass:pass },function(data) {
				// console.log(data);
				if($.trim(data)=="Admin")
				{
					$("#msgbox").fadeTo(200,0.1,function()  //start fading the messagebox
					{ 
					  //add message and change the class of the box and start fading
					  $(this).html('Logging in.....').addClass('error-success').fadeTo(900,1,
		              function()
					  {
						 
						 document.location='admin/adminpage.php';
					  });
					  
					});
				}
				else if ($.trim(data)=="Error") 
				{
					$("#msgbox").fadeTo(200,0.1,function()  //start fading the messagebox
					{ 
					  //add message and change the class of the box and start fading
					  $("#msgbox").html('<span style="color:red">Incorrect Email Id or Password!</span>').addClass('error-warning').fadeTo(900,1);
					  
					});

				}
				else 
				{
					$("#msgbox").fadeTo(200,0.1,function()  //start fading the messagebox
					{ 
					  //add message and change the class of the box and start fading
					  $(this).html('Logging in.....').addClass('error-success').fadeTo(900,1,
		              function()
					  {
						 document.location='home.php';
					  });
					  
					});
				}
			});
			return false;
		});
    </script>
		
</body>

</html>
