<?php

?>
<!DOCTYPE HTML>
<head>
	<title>Ask/Help Complaint Box</title>
</head>
<body>
     <h2><p align="center">Ask / Help Report Details: </p></h4><br>  
      <ul class="container">
          <li><img src="https://jamesgilberdphotography.weebly.com/uploads/1/3/6/5/13650410/editor/emma-not-smiling-35x45_1.jpg?1502668408" width="100" height="120" border="5" /></li>
      </ul>
   <form>  	       	
    <div>
        <label for="name">Name: </label>
        <input id="name" name="Name" disabled>
    </div>
    <div>
        <label for="name">Pin: </label>
        <input id="number" name="Pin" disabled>
    </div>
    <div>
        <label for="name">Address: </label>
        <input id="name" name="Address" disabled>
    </div>
    <div>
        <label for="city">City: </label>
        <input id="name" name="City" disabled>
    </div>
    <div>
        <label for="name">State: </label>
        <input id="name" name="State" disabled>
    </div>
    <div>
        <label for="city">Country: </label>
        <input id="name" name="Country" disabled>
    </div>
    <div>
        <label for="msg">Complain: </label>
        <textarea id="msg" name="Complain" disabled></textarea>
    </div>
</form>
</body>
<style>
form {
  margin: -200px auto;
  width: 400px;
  padding: 1em;
  border: 1px solid #CCC;
  border-radius: 1em;
}
form div + div {
  margin-top: 1em;
}

label {
  display: inline-block;
  width: 90px;
  text-align: right;
}

input, textarea {
    font: 1em sans-serif;

    width: 300px;
    box-sizing: border-box;
    border: 1px solid #999;
}

input:focus, textarea:focus {
  border-color: #000;
}

textarea {
  vertical-align: top;
  height: 5em;
}
.container {
    margin: -100px 200px;
    overflow:hidden;
    list-style:none;
}

.container li {
    float:right;
    text-align:center;
    margin-top: 10em;
}

.container img {
    display:block;
}
</style>
</html>                                            