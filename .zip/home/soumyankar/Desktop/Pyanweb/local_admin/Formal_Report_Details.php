<?php
  session_start();
  include ("../connect.php");
  $c_id=$_GET['c_id'];
  $sql="SELECT * FROM `formal_report` WHERE `hash_id` = '$c_id' ";
  $result=mysqli_query($conn,$sql);
  $found=mysqli_fetch_array($result,MYSQLI_ASSOC);
  $lat="22.469649";
  $long="88.363137";
?>
<!DOCTYPE HTML>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBu3L6GEn3mkYd-ZAJDBz-6xuQUkH1r7pw&libraries=places">
</script>
<head>
	<title>Formal Report Complaint Box</title>
</head>
<body>
     <h2><p align="center">Formal Report Details: </p></h4><br>  
      <ul class="container">
          <li><img src="https://jamesgilberdphotography.weebly.com/uploads/1/3/6/5/13650410/editor/emma-not-smiling-35x45_1.jpg?1502668408" width="100" height="120" border="5" /></li>
      </ul>
   <form>  	       	
    <div>
        <label for="name">Name: </label>
        <input id="name" name="Name" value="<?php echo $found['name']?>" disabled>
    </div>
    <div>
        <label for="name">Pin: </label>
        <input id="number" name="Pin" value="<?php echo $found['pin'] ?>" disabled>
    </div>
    <div>
        <label for="city">City: </label>
        <input id="name" name="City" value="<?php echo $found['city'] ?>" disabled>
    </div>
    <div>
        <label for="city">Country: </label>
        <input id="name" name="Country" value="<?php echo $found['country'] ?>" disabled>
    </div>
    <div>
        <label for="msg">Complain: </label>
        <textarea id="msg" name="Complain" disabled><?php echo $found['complaint'] ?></textarea>
    </div>
</form>
      <div class="Format" name="image"><h3 align="center">Relevant Information : </h3></div>
      <form>
      <div>
        <label for="msg">Police Station Details: </label>
        <textarea id="msg" name="Details" disabled></textarea>
      </div>
    </form><br>
      <div class="Format" name="image"><h3 align="center">Other Evidences : </h3></div>
      <ul class="NewContainer">
          <li><img src="https://jamesgilberdphotography.weebly.com/uploads/1/3/6/5/13650410/editor/emma-not-smiling-35x45_1.jpg?1502668408" width="100" height="120" border="5" /></li>
          <li><img src="https://jamesgilberdphotography.weebly.com/uploads/1/3/6/5/13650410/editor/emma-not-smiling-35x45_1.jpg?1502668408" width="100" height="120" border="5" /></li>
          <li><img src="https://jamesgilberdphotography.weebly.com/uploads/1/3/6/5/13650410/editor/emma-not-smiling-35x45_1.jpg?1502668408" width="100" height="120" border="5" /></li>
      </ul>




 <script>
     
     var lat1 = "<?php echo $lat ?>";
     var long1 ="<?php echo $long ?>";
      var map;
      var infowindow;
      function initMap() {
       var pyrmont = {lat: parseFloat(lat1), lng: parseFloat(long1)};

        map = new google.maps.Map(document.getElementById('map'), {
          center: pyrmont,
          zoom: 15
        });

        infowindow = new google.maps.InfoWindow();
        var service = new google.maps.places.PlacesService(map);
        service.nearbySearch({
          location: pyrmont,
          radius: 5000,
          type: ['police']
        }, callback);
      }


      function callback(results, status) {
        if (status === google.maps.places.PlacesServiceStatus.OK) {
          for (var i = 0; i < results.length; i++) {
            createMarker(results[i]);
          }
        }
      }

      function createMarker(place) {
        var placeLoc = place.geometry.location;
        var marker = new google.maps.Marker({
          map: map,
          position: place.geometry.location
        });

        google.maps.event.addListener(marker, 'click', function() {
          infowindow.setContent(place.name);
          infowindow.open(map, this);
        });
      }

      google.maps.event.addDomListener(window, 'load', initMap);
    </script>





</body>

<center>
  <div id="map" style="width:400px;height:400px">Nearby police staion</div>
</center>

<style>
form {
  margin: -200px auto;
  width: 400px;
  padding: 1em;
  border: 1px solid #CCC;
  border-radius: 1em;
}
form div + div {
  margin-top: 1em;
}

label {
  display: inline-block;
  width: 90px;
  text-align: right;
}

input, textarea {
    font: 1em sans-serif;

    width: 300px;
    box-sizing: border-box;
    border: 1px solid #999;
}

input:focus, textarea:focus {
  border-color: #000;
}

textarea {
  vertical-align: top;
  height: 5em;
}
.Format{
  margin: 220px auto;
}
.container {
    margin: -100px 200px;
    overflow:hidden;
    list-style:none;
}

.container li {
    float:right;
    text-align:center;
    margin-top: 10em;
}

.container img {
    display:block;
}



.NewContainer {
    margin: -350px 400px;
    overflow:hidden5
    list-style:none;
}

.NewContainer li {
    float:right;
    text-align:center;
    margin-top: 10em;
    margin-right: 1em; 
}

.NewContainer img {
    display:block;
}
</style>
</html>                                            