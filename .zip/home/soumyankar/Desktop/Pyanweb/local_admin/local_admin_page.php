<?php
    include ("../connect.php");
    session_start();
    $state=$_SESSION['local_admin'];
    
?>
<html>
<head>
<!--  <link rel="stylesheet" type="text/css" href="css/table.css">-->
<!--  <link rel="stylesheet" type="text/css" href="css/form.css">-->
  <title>Local Admin </title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="../css/agency.css" rel="stylesheet">
  <script type="text/javascript"  src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.1/jquery.min.js"></script>
  
  <style>
    body {
      /*background-color: #ccccff;*/
      background-color: grey;

    }
    table, th, td {
      border: 2px solid black;
    }
    td,th,btn {
      padding: 1em;
      width:50px;
    }

  </style>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header page-scroll">
      <button type="button" class="navbar-toggle" data-toggle="collapse"
              data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span> <span
            class="icon-bar"></span> <span class="icon-bar"></span> <span
            class="icon-bar"></span>
      </button>
      <a class="navbar-brand page-scroll" href="local_admin_page.php">Local Admin for <?php echo $state; ?></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse"
         id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="admin_logout.php" class="btn btn-primary"> Logout</a></li>
      </ul>
    </div>
    <!-- /.navbar-collapse -->
  </div>
  <!-- /.container-fluid -->
</nav>

<section>
  <center>
    <form type="get" action="search.php">
      <div id="custom-search-input">
        <div class="input-group col-md-5">
          <input type="text" class="form-control input-lg" name='search_id' placeholder="Enter Complaint ID" />
          <span class="input-group-btn">
              <button class="btn btn-info btn-lg" type="submit">
                  <i class="glyphicon glyphicon-search"></i>
              </button>
          </span>
        </div>
      </div>
    </form>
  </center>
  <h2 class="aa_h2" align="center">Help/Protection Requests</h2>
  <div class="aa_htmlTable">

    <br />
    <div style="">
    <table align="center" border="5">
      <thead>
        <tr>
          <th>Complaint ID</th>
          <th>Complainant Name</th>
          <th>Pin</th>        
          <th>Violent Factor Assessment</th>
          <th>Violent Factor Ratio</th>
          <th>Request Details</th>
        </tr>
      </thead>
      <tbody>
        <?php
          $sql="Select * from help_protection where state='$state'";
          $result=mysqli_query($conn,$sql);
          $found=mysqli_num_rows($result);
          if(!$found)
          {
            // echo "<h4 style=\"position:absolute; top:60%; left:60%\">--No Requests--</h4>";
          }
          else
          {
            while($found=mysqli_fetch_array($result,MYSQLI_ASSOC))
            {
              // $id=$found['user_id'];
              // $sql2="Select * from users where ID='$id'";
              // $query=mysqli_query($conn,$sql2);
              // $user=mysqli_fetch_array($query,MYSQLI_ASSOC);
              // $c_id=$found['hash_id'];
              ?>
              <tr>
                <td><?php echo $found['hash_id']; ?></td>
                <td><?php echo $found['name']?> </td>
                <td><?php echo $found['pin']; ?></td>
                <td><?php echo "God knows" ?></td>
                <td><?php echo "Kaun dega code? tera papa?" ?></td>
                <td><a class="btn btn-success" href="#">See Complaint Details</a></td>
              </tr>
              <?php
            }
          }  
        ?>
      </tbody>
    </table>
  </div>
  </div>

  <h2 class="aa_h2" align="center">Formal Reports</h2>
  <div class="aa_htmlTable">

    <br />
    <div >
    <table align="center" border="5">
      <thead>
        <tr>
          <th>Complaint ID</th>
          <th>Complainant Name</th>
          <th>Pin</th>        
          <th>Violent Factor Assessment</th>
          <th>Violent Factor Ratio</th>
          <th>Report Details</th>
        </tr>
      </thead>
      <tbody>
        <?php
          $sql="Select * from formal_report where State='$state'";
          $result=mysqli_query($conn,$sql);
          $found=mysqli_num_rows($result);
          if(!$found)
          {
            // echo "<h4 style=\"position:absolute; top:60%; left:60%\">--No Quick Complaints--</h4>";
          }
          else
          {
            while($found=mysqli_fetch_array($result,MYSQLI_ASSOC))
            {
              ?>
              <tr>
                <td><?php echo $found['hash_id']; ?></td>
                <td><?php echo $found['name']; ?></td>
                <td><?php echo $found['pin']; ?></td>
                <td><?php echo "God Knows" ?></td>
                <td><?php echo "Code kaun degA? tera papa?" ?></td>
                <td><a class="btn btn-success" href="Formal_Report_Details.php?c_id=<?php echo $found['hash_id']; ?>">See Report Deatils</a>
                </td>
              </tr>
              <?php
            }
          }  
        ?>
      </tbody>
    </table>
  </div>
  </div>

  <h2 class="aa_h2" align="center">Quick Reports</h2>
  <div class="aa_htmlTable">
    <br />
    <div >
    <table align="center" border="5">
      <thead>
        <tr>
          <th>Complaint ID</th>
          <th>Complainant Name</th>
          <th>Pin</th>        
          <th>Violent Factor Assessment</th>
          <th>Violent Factor Ratio</th>
          <th>Report Details</th>
        </tr>
      </thead>
      <tbody>
        <?php
          $sql="Select * from quick_report where State='$state'";
          $result=mysqli_query($conn,$sql);
          $found=mysqli_num_rows($result);
          if(!$found)
          {
            // echo "<h4 style=\"position:absolute; top:60%; left:60%\">--No Quick Complaints--</h4>";
          }
          else
          {
            while($found=mysqli_fetch_array($result,MYSQLI_ASSOC))
            {
              ?>
              <tr>
                <td><?php echo $found['hash_id']; ?></td>
                <td><?php echo $found['name']; ?></td>
                <td><?php echo $found['pin']; ?></td>
                <td><?php echo "God Knows" ?></td>
                <td><?php echo "Code kaun degA? tera papa?" ?></td>
                <td><a class="btn btn-success" href="#">See Complaint Details</a></td>
              </tr>
              <?php
            }
          }  
        ?>
      </tbody>
    </table>
  </div>
  </div>

</section>
</body>
</html>

