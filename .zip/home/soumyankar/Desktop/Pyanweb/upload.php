<?php
  session_start();
 include ("connect.php");
 include "HashGenerator.php";

      $errors= array();
      $file_name = $_FILES['image']['name'];
      // $file_size =$_FILES['image']['size'];
       $file_tmp =$_FILES['image']['tmp_name'];
      // $file_type=$_FILES['image']['type'];
      // $k='.';
      //   $file_ext=strtolower(end(explode($k,$file_name)));
      // $expensions= array("jpeg","jpg","png");
      // if(in_array($file_ext,$expensions)=== false){
      //     $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      //  }
      $state=$_POST['state'];
      $name=$_POST['name'];
      $image_id=$_FILES['image']['name'];
      $city=$_POST['city'];
      $pin=$_POST['pin'];
      $country=$_POST['country'];
      $complaint=$_POST['complaint'];
      $path1=$_FILES['fileInput1']['name'];
      $path1_tmp=$_FILES['fileInput1']['tmp_name'];
      $file1=$path1;
      $path2=$_FILES['fileInput2']['name'];
      $file2=$path2;
      $path2_tmp=$_FILES['fileInput2']['tmp_name'];
      $path3=$_FILES['fileInput3']['name'];
      $file3=$path3;
      $path3_tmp=$_FILES['fileInput3']['tmp_name'];
        // var_dump($c_id);
    	$sql="INSERT INTO `formal_report` (`complaint_id`, `image_name`, `name`, `pin`, `city`, `country`, `complaint`, `file1`,`file2`,`file3`,`state`) VALUES (NULL,'$image_id','$name','$pin','$city','$country','$complaint','$file1','$file2','$file3','$state')";
      $query=mysqli_query($conn,$sql);
      if(!$query)
      {
        echo "Not Inserted". "<br>" . mysqli_error($conn);
      }  
      $sql2="Select LAST_INSERT_ID() as c_id";
      $query2=mysqli_query($conn,$sql2);
      $result2=mysqli_fetch_assoc($query2);
      $c_id=($result2['c_id']);
        $obj = new HashGenerator;
        $hash_id = $obj->encode($c_id);
        $sql3="UPDATE formal_report SET hash_id='$hash_id' WHERE complaint_id='$c_id'";
        $query=mysqli_query($conn,$sql3);
        if(!$query)
        {
          echo "Not Updated". "<br>" . mysqli_error($conn);
        }
        $sql4="UPDATE formal_report SET image_name='$c_id' WHERE complaint_id='$c_id' ";
        $query=mysqli_query($conn,$sql4);
        if(!$query)
        {
          echo "Not Updated". "<br>" . mysqli_error($conn);
        }
        $path1=$c_id."_file1";
        $path2=$c_id."_file2";
        $path3=$c_id."_file3";
        $file_name=$c_id."_image";
        if(empty($errors)==true){
         move_uploaded_file($file_tmp,"images/".$file_name);
         move_uploaded_file($path1_tmp,"images/".$path1);
         move_uploaded_file($path2_tmp,"images/".$path2);
         move_uploaded_file($path3_tmp,"images/".$path3);
      }else{
         print_r($errors);
      }
        $sql5="UPDATE formal_report SET image_name='$file_name' , file1='$path1' , file2='$path2' , file3='$path3' WHERE complaint_id='$c_id' ";
        $query=mysqli_query($conn,$sql5);
        if(!$query)
        {
          echo "Not Updated". "<br>" . mysqli_error($conn);
        }
        header("location:Confirmation_Page.php?c_id=$hash_id");
      ?>